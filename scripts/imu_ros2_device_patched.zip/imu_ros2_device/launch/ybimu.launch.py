import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    filter_cfg = os.path.join(
        get_package_share_directory('imu_ros2_device'),
        'config', 'imu_filter_param.yaml')

    return LaunchDescription([
        DeclareLaunchArgument('port', default_value='/dev/ttyUSB1'),
        DeclareLaunchArgument('rate_hz', default_value='50.0'),
        Node(
            package='imu_ros2_device',
            executable='ybimu_driver',
            output='screen',
            parameters=[{'port': LaunchConfiguration('port'),
                         'rate_hz': LaunchConfiguration('rate_hz')}],
        ),
        Node(
            package='imu_filter_madgwick',
            executable='imu_filter_madgwick_node',
            output='screen',
            parameters=[filter_cfg],
        ),
    ])
