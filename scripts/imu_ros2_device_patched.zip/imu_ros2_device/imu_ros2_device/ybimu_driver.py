#!/usr/bin/env python
# encoding: utf-8

# Patched: port / rate / frame are ROS parameters, and the driver no longer
# falls back to /dev/ttyUSB0 (which is the lidar on this robot).

import rclpy
from rclpy.node import Node
from rclpy.clock import Clock
from sensor_msgs.msg import Imu, MagneticField
from std_msgs.msg import Float32MultiArray

try:
    from YbImuLib import YbImuSerial
except ImportError:
    # allow dropping YbImuLib.py into this package folder
    from .YbImuLib import YbImuSerial


class ybimu_driver(Node):
    def __init__(self, name):
        super().__init__(name)
        self.robot = None
        self.declare_parameter('port', '/dev/ttyUSB1')
        self.declare_parameter('rate_hz', 50.0)
        self.declare_parameter('frame_id', 'imu_link')

    def init_topic(self):
        port = self.get_parameter('port').value
        rate = float(self.get_parameter('rate_hz').value)
        self.frame_id = self.get_parameter('frame_id').value

        try:
            self.robot = YbImuSerial(port)
            self.get_logger().info("Open Ybimu Port OK: %s" % port)
        except Exception as e:
            self.get_logger().error(
                "Fail to open Ybimu serial port %s: %s" % (port, e))
            return
        self.robot.create_receive_threading()

        # create publisher
        self.imuPublisher = self.create_publisher(Imu, "imu/data_raw", 100)
        self.magPublisher = self.create_publisher(MagneticField, "imu/mag", 100)
        self.baroPublisher = self.create_publisher(Float32MultiArray, "baro", 100)
        self.eulerPublisher = self.create_publisher(Float32MultiArray, "euler", 100)

        # create timer
        self.timer = self.create_timer(1.0 / rate, self.pub_data)

    def pub_data(self):
        if self.robot is None:
            return
        stamp = Clock().now().to_msg()
        imu = Imu()
        mag = MagneticField()
        baro = Float32MultiArray()
        euler = Float32MultiArray()

        [ax, ay, az] = self.robot.get_accelerometer_data()
        [gx, gy, gz] = self.robot.get_gyroscope_data()
        [mx, my, mz] = self.robot.get_magnetometer_data()
        [q0, q1, q2, q3] = self.robot.get_imu_quaternion_data()
        [height, temperature, pressure, pressure_contrast] = self.robot.get_baro_data()
        [roll, pitch, yaw] = self.robot.get_imu_attitude_data(True)

        imu.header.stamp = stamp
        imu.header.frame_id = self.frame_id
        imu.linear_acceleration.x = ax * 1.0
        imu.linear_acceleration.y = ay * 1.0
        imu.linear_acceleration.z = az * 1.0
        imu.angular_velocity.x = gx * 1.0
        imu.angular_velocity.y = gy * 1.0
        imu.angular_velocity.z = gz * 1.0
        imu.orientation.w = q0
        imu.orientation.x = q1
        imu.orientation.y = q2
        imu.orientation.z = q3

        mag.header.stamp = stamp
        mag.header.frame_id = self.frame_id
        mag.magnetic_field.x = mx * 1.0
        mag.magnetic_field.y = -my * 1.0
        mag.magnetic_field.z = mz * 1.0

        baro.data = [height, temperature, pressure, pressure_contrast]
        euler.data = [roll, pitch, yaw]

        self.imuPublisher.publish(imu)
        self.magPublisher.publish(mag)
        self.baroPublisher.publish(baro)
        self.eulerPublisher.publish(euler)

    def ready(self):
        return self.robot is not None


def main(args=None):
    rclpy.init(args=args)
    node = ybimu_driver("ybimu_node")
    node.init_topic()
    if not node.ready():
        node.destroy_node()
        rclpy.shutdown()
        return
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()


if __name__ == "__main__":
    main()
